# Splunk Log Parsing, Filtering & Normalization Sample Files

## Log Files Provided
- apache.log : Sample Apache web server access logs
- syslog.log : Sample syslog with ssh authentication events
- windows_security.csv : Sample Windows security logs (CSV format)

## Sample SPL Queries

### 1. Parsing Apache Logs
```
index=apache_logs
| rex field=_raw "(?<src_ip>\d{1,3}(?:\.\d{1,3}){3}) - - \[(?<timestamp>[^\]]+)\] \"(?<method>\w+) (?<url>[^\s]+) HTTP\/1\.1\" (?<status>\d{3}) (?<bytes>\d+)"
| table src_ip timestamp method url status bytes
```

### 2. Filtering Failed Logins (Syslog)
```
index=syslog_logs "Failed password"
```

### 3. Normalizing Windows Logs
```
index=windows_logs
| eval src=Source_Network_Address, user=Account_Name, action=if(EventCode==4625, "login_failed", "login_success")
| table src user action
```

---
Happy Splunking! 🚀
